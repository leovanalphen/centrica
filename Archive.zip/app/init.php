<?php 
session_start();
require_once 'core/app.php';
require_once 'core/controller.php';
require_once 'core/model.php';