		</div>
		<footer>
			<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation">
  				<div class="container-fluid">
    				<div class="navbar-header">
      					<a class="navbar-brand" href="/public">Centrica Copyright 2014</a>
      				</div>
    			</div>
  		</div>
	</nav>
		</footer>
	</div>
	</body>
</html>