<?php require_once('../app/views/layouts/header.php'); ?>
<p>Welkom bij Centrica, de beheerapplicatie van scholengemeenschap de hondsrug</p>
<?php require_once('../app/views/layouts/footer.php'); ?>