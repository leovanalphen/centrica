<?php require_once('../app/views/layouts/header.php'); ?>

<?php require_once('../app/views/layouts/footer.php'); ?>