<?php require_once('../app/views/layouts/header.php'); ?>
Dit is het configuratie scherm!
<?php require_once('../app/views/layouts/footer.php'); ?>